Prereuisites:

.NET Core 2.1

Change connection string in WebShop\appsettings.json

Build solution:

dotnet build

Run tests:

dotnet test WebShop.UnitTests

Run project:

dotnet run --project WebShop